# news-research-tool-langchain
You can deploy the app using : 
```
streamlit run main.py
```
